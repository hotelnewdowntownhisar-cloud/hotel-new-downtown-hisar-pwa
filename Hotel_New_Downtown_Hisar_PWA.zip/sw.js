const CACHE_NAME='hotel-new-downtown-shell-v1';
const SHELL=['./','./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE_NAME).then(cache=>cache.addAll(SHELL)));self.skipWaiting();});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 // Cache only this PWA's static shell. Never cache private hotel data or Apps Script responses.
 if(url.origin===self.location.origin && event.request.method==='GET'){
  event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request)));
 }
});
